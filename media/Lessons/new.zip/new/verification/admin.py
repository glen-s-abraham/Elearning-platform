from django.contrib import admin
from verification.models import doc

admin.site.register(doc)

