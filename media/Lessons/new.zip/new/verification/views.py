from django.shortcuts import render
from django.http import HttpResponse
from .models import doc
def verification(request):
	context={'data':doc.objects.get(user_name="user1")}
	if request.method=='POST':
		user_name=request.POST.get('user_name')
		key=request.POST.get('key')
		print(user_name,key)
		try:
		  	val=doc.objects.get(user_name=user_name,key=key)
		except:
		 	print("invalid dwnload url")
		else:
		 	print("valid url")


		
	return render(request,'home/verification.html',context)

