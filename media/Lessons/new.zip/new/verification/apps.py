from django.apps import AppConfig


class VerificationConfig(AppConfig):
    name = 'verification'
